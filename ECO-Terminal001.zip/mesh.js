// 🌐 ECO-Terminal001 - Servidor Mesh Local (Node.js + WebSocket)
import { WebSocketServer } from "ws";

const wss = new WebSocketServer({ port: 8080 });
console.log("🧠 ECO-Terminal ativo — aguardando conexões...");

wss.on("connection", ws => {
  console.log("📡 Novo dispositivo conectado ao Mesh Local.");

  ws.on("message", msg => {
    console.log("💬 Evento recebido:", msg.toString());

    wss.clients.forEach(client => {
      if (client !== ws && client.readyState === 1) {
        client.send(msg.toString());
      }
    });
  });
});
