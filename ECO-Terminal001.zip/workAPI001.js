// 🚀 WorkAPI001 - Gateway rápido entre Terminal001 e KernelOSIA001
import WebSocket from "ws";

const socket = new WebSocket("ws://localhost:8080");
socket.on("open", () => console.log("🔗 WorkAPI001 conectado ao Mesh Local"));
socket.on("message", data => console.log("📨 Dados recebidos:", data.toString()));

setInterval(() => {
  const ping = JSON.stringify({
    agent: "ECO-Terminal001",
    type: "heartbeat",
    time: new Date().toISOString()
  });
  socket.send(ping);
}, 5000);
